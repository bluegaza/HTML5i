These plugins are an example. You can edit, remove or add others.
For free support: http://cmsphotogallery.com/